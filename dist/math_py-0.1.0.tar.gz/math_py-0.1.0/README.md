# Math_py Library

    **Mathematical Calculation Python Library**
1. Install:

```
pip install math_py
```

2. Capture numbers:

```python
from math_py import * or from math_py import [package name]

# initialise visual arts
drive = calculate.Drive()

```
